declare module 'ember-get-config' {
    export default object;
}