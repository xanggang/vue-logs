'use strict';

module.exports = {
  extends: 'octane'
};
