export type Extra = unknown;
export type Extras = Record<string, Extra>;
