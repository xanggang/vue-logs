/** JSDoc */
export interface Package {
  name: string;
  version: string;
}
