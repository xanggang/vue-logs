/** Runtime Context. */
export interface Runtime {
  name?: string;
  version?: string;
}
