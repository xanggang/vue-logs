export function getError(): Error {
  return new Error('mock error');
}
