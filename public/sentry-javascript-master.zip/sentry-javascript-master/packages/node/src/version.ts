export const SDK_NAME = 'sentry.javascript.node';
export const SDK_VERSION = '5.20.1';
