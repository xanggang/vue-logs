Assuming `npm@>=5.2.0` is installed and `@sentry/browser` package is built locally:

```sh
$ npx serve -S
```
